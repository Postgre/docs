package north.marketaccess.javafx.demo;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.animation.TimelineBuilder;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.LabelBuilder;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderPaneBuilder;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

public class DemoTimeLine extends Application {

  @Override
  public void start(Stage stage) throws Exception {
    // Create Label to show
    final Label label = LabelBuilder.create().text("TimeLine").font(new Font(80)).alignment(Pos.CENTER).build();

    // Create KeyFrame with default values on x and y axis
    KeyValue xBase = new KeyValue(label.scaleXProperty(), 1);
    KeyValue yBase = new KeyValue(label.scaleYProperty(), 1);
    KeyFrame base = new KeyFrame(Duration.millis(0), xBase, yBase);

    // Create KeyFrame with bigger values on x and y axis
    KeyValue xBig = new KeyValue(label.scaleXProperty(), 1.2);
    KeyValue yBig = new KeyValue(label.scaleYProperty(), 1.2);
    KeyFrame big = new KeyFrame(Duration.millis(500), xBig, yBig);

    // Create TimeLine with KeyFrames
    final Timeline timeLine =
        TimelineBuilder.create().targetFramerate(50).autoReverse(true).cycleCount(1).keyFrames(base, big).build();

    // Start animation from start when mouse entered on Label
    label.setOnMouseEntered(new EventHandler<MouseEvent>() {

      @Override
      public void handle(MouseEvent paramT) {
        timeLine.setRate(1);
        timeLine.playFromStart();
      }
    });

    // Start animation from end when mouse entered on Label
    label.setOnMouseExited(new EventHandler<MouseEvent>() {

      @Override
      public void handle(MouseEvent paramT) {
        timeLine.setRate(-1);
        timeLine.play();
      }
    });

    // Show Label on Scene
    BorderPane pane = BorderPaneBuilder.create().center(label).build();
    Scene scene = new Scene(pane, 600, 300);
    stage.setScene(scene);
    stage.setTitle("Demo time line");
    stage.show();
  }

  public static void main(String[] args) {
    Application.launch(args);
  }

}
