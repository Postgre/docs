package north.marketaccess.javafx.demo;

import java.util.List;

import com.google.common.collect.Lists;

public final class BookUtility {

  private BookUtility() {
    // Can not be instanced
  }

  public static List<Book> getBooks() {
    Book book1 = new Book("Java 7", "Robert Chevallier", "Campus Press ", 250, 22);
    Book book2 = new Book("JavaFX 2.0: Introduction by Example", "Carl Dea", "Apress ", 200, 25.70);
    Book book3 = new Book("Pro JavaFX 2", "Jim Weaver", "Apress ", 640, 49.99);
    Book book4 = new Book("The Pragmatic Programmer", "Andrew Hunt ", "Addison Wesley", 352, 33.97);
    Book book5 = new Book("Java Concurrency in Practice", "Brian Goetz", "Addison Wesley", 384, 46.63);
    return Lists.newArrayList(book1, book2, book3, book4, book5);
  }

}
