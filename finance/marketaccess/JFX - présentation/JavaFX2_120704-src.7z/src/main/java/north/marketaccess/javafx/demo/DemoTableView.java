package north.marketaccess.javafx.demo;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class DemoTableView extends Application {

  @Override
  public void start(Stage stage) throws Exception {
    // Create TableView
    TableView<Book> table = new TableView<>();

    // Add datas into TableView
    table.getItems().addAll(BookUtility.getBooks());

    // Init TableColumns
    TableColumn<Book, String> colTitle = new TableColumn<>("Title");
    colTitle.setCellValueFactory(new PropertyValueFactory<Book, String>("title"));

    TableColumn<Book, String> colAuthor = new TableColumn<>("Author");
    colAuthor.setCellValueFactory(new PropertyValueFactory<Book, String>("author"));

    TableColumn<Book, String> colEditor = new TableColumn<>("Editor");
    colEditor.setCellValueFactory(new PropertyValueFactory<Book, String>("editor"));

    TableColumn<Book, Integer> colPages = new TableColumn<>("Pages");
    colPages.setCellValueFactory(new PropertyValueFactory<Book, Integer>("pages"));

    TableColumn<Book, Double> colPrice = new TableColumn<>("Price");
    colPrice.setCellValueFactory(new PropertyValueFactory<Book, Double>("price"));

    // Add columns into TableView
    table.getColumns().addAll(colTitle, colAuthor, colEditor, colPages, colPrice);

    // Show stage
    Scene scene = new Scene(table);
    stage.setScene(scene);
    stage.setTitle("Demo for TableView");
    stage.show();
  }

  public static void main(String[] args) {
    Application.launch(args);
  }

}
