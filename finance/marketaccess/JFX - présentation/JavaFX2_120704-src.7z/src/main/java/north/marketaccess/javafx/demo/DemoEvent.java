package north.marketaccess.javafx.demo;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBuilder;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class DemoEvent extends Application {

  @Override
  public void start(Stage stage) throws Exception {
    // Create button with event handlers
    final Button button = ButtonBuilder.create().text("Button").font(new Font(20)).build();

    // When user click on it
    button.setOnAction(new EventHandler<ActionEvent>() {

      @Override
      public void handle(ActionEvent event) {
        button.setText("button has been clicked");
      }
    });

    // When user type key
    button.setOnKeyPressed(new EventHandler<KeyEvent>() {

      @Override
      public void handle(KeyEvent event) {
        button.setText("key has been typed : " + event.getText());
      }
    });

    stage.setScene(new Scene(button, 600, 400));
    stage.setTitle("Demo event");
    stage.show();
  }

  public static void main(String[] args) {
    Application.launch(args);
  }

}
