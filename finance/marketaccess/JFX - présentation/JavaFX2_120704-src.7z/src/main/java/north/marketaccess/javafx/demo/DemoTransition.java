package north.marketaccess.javafx.demo;

import javafx.animation.FadeTransition;
import javafx.animation.FadeTransitionBuilder;
import javafx.animation.FillTransition;
import javafx.animation.FillTransitionBuilder;
import javafx.animation.ParallelTransitionBuilder;
import javafx.animation.RotateTransition;
import javafx.animation.RotateTransitionBuilder;
import javafx.animation.Transition;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderPaneBuilder;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextBuilder;
import javafx.stage.Stage;
import javafx.util.Duration;

public class DemoTransition extends Application {

  @Override
  public void start(Stage stage) throws Exception {
    // Create Label
    final Text label = TextBuilder.create().text("Transition").font(new Font(80)).build();

    // Duration of all transitions
    Duration duration = Duration.millis(2000);

    // FadeTransition
    FadeTransition fade =
        FadeTransitionBuilder.create().duration(duration).node(label).fromValue(1).toValue(0.3).build();

    // RotateTransition
    RotateTransition rotate =
        RotateTransitionBuilder.create().duration(duration).node(label).fromAngle(0).toAngle(180).build();

    // FillTransition
    FillTransition fill =
        FillTransitionBuilder.create().duration(duration).shape(label).fromValue(Color.BLACK).toValue(Color.BLUE)
            .build();

    // Create ParallelTransition with other Transitions
    final Transition transition =
        ParallelTransitionBuilder.create().targetFramerate(50).autoReverse(true).cycleCount(1)
            .children(fade, rotate, fill).build();

    // Start animation from start when mouse entered on Label
    label.setOnMouseEntered(new EventHandler<MouseEvent>() {

      @Override
      public void handle(MouseEvent paramT) {
        transition.setRate(1);
        transition.playFromStart();
      }
    });

    // Start animation from end when mouse entered on Label
    label.setOnMouseExited(new EventHandler<MouseEvent>() {

      @Override
      public void handle(MouseEvent paramT) {
        transition.setRate(-1);
        transition.play();
      }
    });

    // Init Layout
    BorderPane pane = BorderPaneBuilder.create().center(label).build();
    BorderPane.setAlignment(label, Pos.CENTER);
    BorderPane.setMargin(label, new Insets(6));

    // Show Label on Scene
    Scene scene = new Scene(pane, 600, 300);
    stage.setScene(scene);
    stage.setTitle("Demo transition");
    stage.show();
  }

  public static void main(String[] args) {
    Application.launch(args);
  }

}
