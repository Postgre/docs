package north.marketaccess.javafx.demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderPaneBuilder;
import javafx.stage.Stage;

public class DemoLayout extends Application {

  @Override
  public void start(Stage stage) throws Exception {
    // Create buttons
    Button topButton = new Button("Top");
    Button bottomButton = new Button("Bottom");
    Button leftButton = new Button("Left");
    Button rightButton = new Button("Right");
    Button centerButton = new Button("Center");

    // Create pane
    BorderPane pane =
        BorderPaneBuilder.create().top(topButton).bottom(bottomButton).left(leftButton).right(rightButton)
            .center(centerButton).build();

    // Initialize alignment
    BorderPane.setAlignment(topButton, Pos.CENTER);
    BorderPane.setAlignment(bottomButton, Pos.CENTER);
    BorderPane.setAlignment(rightButton, Pos.CENTER);
    BorderPane.setAlignment(leftButton, Pos.CENTER);

    // Intialize constraints
    BorderPane.setMargin(topButton, new Insets(6));
    BorderPane.setMargin(bottomButton, new Insets(6));
    BorderPane.setMargin(leftButton, new Insets(6));
    BorderPane.setMargin(rightButton, new Insets(6));

    stage.setScene(new Scene(pane));
    stage.setTitle("Demo layout");
    stage.show();
  }

  public static void main(String[] args) {
    Application.launch(args);
  }

}
