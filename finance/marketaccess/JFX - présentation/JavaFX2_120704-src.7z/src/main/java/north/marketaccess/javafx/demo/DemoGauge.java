package north.marketaccess.javafx.demo;

import javafx.animation.Animation;
import javafx.animation.Transition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import jfxtras.labs.scene.control.gauge.ColorDef;
import jfxtras.labs.scene.control.gauge.Gauge;
import jfxtras.labs.scene.control.gauge.GaugeBuilder;
import jfxtras.labs.scene.control.gauge.LcdDesign;
import jfxtras.labs.scene.control.gauge.Marker;
import jfxtras.labs.scene.control.gauge.Section;

public class DemoGauge extends Application {

  @Override
  public void start(Stage stage) throws Exception {
    // Create gauge
    final Gauge gauge =
        GaugeBuilder
            .create(GaugeBuilder.GaugeType.RADIAL)
            .frameDesign(Gauge.FrameDesign.STEEL)
            .backgroundDesign(Gauge.BackgroundDesign.DARK_GRAY)
            .lcdDesign(LcdDesign.STANDARD_GREEN)
            .lcdDecimals(2)
            .lcdValueFont(Gauge.LcdFont.LCD)
            .pointerType(Gauge.PointerType.TYPE14)
            .valueColor(ColorDef.RED)
            .knobDesign(Gauge.KnobDesign.METAL)
            .knobColor(Gauge.KnobColor.SILVER)
            .sections(
                new Section[]{new Section(0, 37, Color.LIME), new Section(37, 60, Color.YELLOW),
                    new Section(60, 75, Color.ORANGE)}).sectionsVisible(true)
            .areas(new Section[]{new Section(75, 100, Color.RED)}).areasVisible(true)
            .markers(new Marker[]{new Marker(30, Color.MAGENTA), new Marker(75, Color.AQUAMARINE)})
            .markersVisible(true).threshold(40).thresholdVisible(true).glowVisible(true).glowOn(true)
            .trendVisible(true).trend(Gauge.Trend.UP).userLedVisible(true).bargraph(true).title("Temperature")
            .unit("�C").build();

    gauge.setPrefWidth(500);
    gauge.setPrefHeight(500);

    // Create update transition
    Transition updateGaugeAnimation = new UpdateGaugeTransition(gauge);
    updateGaugeAnimation.play();

    // Init stage
    stage.setScene(new Scene(gauge));
    stage.setTitle("Demo Gauge");
    stage.show();
  }

  public static void main(String[] args) {
    Application.launch(args);
  }

}

/**
 * Gauge updater
 */
class UpdateGaugeTransition extends Transition {
  private final Gauge gauge;

  public UpdateGaugeTransition(Gauge gauge) {
    super(1);
    this.gauge = gauge;
    setAutoReverse(true);
    setCycleCount(Animation.INDEFINITE);
    setCycleDuration(Duration.millis(5000));
  }

  @Override
  protected void interpolate(double frac) {
    double value = Math.round(frac * 100 * 100) / 100.0;
    gauge.setValue(value);
  }
}
