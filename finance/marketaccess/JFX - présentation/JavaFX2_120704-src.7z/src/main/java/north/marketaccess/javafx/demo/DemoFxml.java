package north.marketaccess.javafx.demo;

import java.util.Random;
import java.util.UUID;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class DemoFxml extends Application {

  @FXML
  private TableView<Book> table;

  @Override
  public void start(Stage stage) throws Exception {
    BorderPane pane = (BorderPane) FXMLLoader.load(getClass().getResource("DemoFxml.fxml"));

    Scene scene = new Scene(pane);
    scene.getStylesheets().add("north/marketaccess/javafx/demo/demo.css");
    stage.setScene(scene);
    stage.setTitle("FXML Demo");
    stage.show();
  }

  @FXML
  private void addBook(ActionEvent event) {
    // Create random book
    String title = "Random Title - " + UUID.randomUUID().toString();
    String author = "Random Author - " + UUID.randomUUID().toString();
    String editor = "Random Editor - " + UUID.randomUUID().toString();
    int pages = new Random().nextInt(600) + 50;
    double price = Math.round(new Random().nextDouble() * 5000 + 1000) / 100.0;
    Book book = new Book(title, author, editor, pages, price);

    // Add it to TableView
    table.getItems().add(book);
  }

  @FXML
  private void removeBook(ActionEvent event) {
    // Precondition: there is at least one book in TableView
    if (table.getItems().isEmpty()) {
      return;
    }

    // Select a random book and remove it
    int index = new Random().nextInt(table.getItems().size());
    table.getItems().remove(index);
  }

  @FXML
  private void clearBooks(ActionEvent event) {
    table.getItems().clear();
  }

  public static void main(String[] args) {
    launch(args);
  }
}
