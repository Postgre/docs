package north.marketaccess.javafx.demo;

import java.util.List;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.stage.Stage;

public class DemoFxCollections extends Application {

  @Override
  public void start(Stage stage) throws Exception {
    // Create datas
    List<Book> books = BookUtility.getBooks();

    // Create ObservableList
    ObservableList<Book> observableBooks = FXCollections.observableArrayList(books);

    // Listen changes on Book
    observableBooks.addListener(new ListChangeListener<Book>() {

      @Override
      public void onChanged(javafx.collections.ListChangeListener.Change<? extends Book> c) {
        while (c.next()) {
          if (c.wasAdded()) {
            System.out.println("Books added: " + c.getAddedSubList());

          } else if (c.wasRemoved()) {
            System.out.println("Books removed: " + c.getRemoved());
          }
        }
      }

    });

    // Remove one item
    Book bookRemoved = observableBooks.remove(0);

    // Add item
    observableBooks.add(bookRemoved);
  }

  public static void main(String[] args) {
    launch(args);
  }

}
