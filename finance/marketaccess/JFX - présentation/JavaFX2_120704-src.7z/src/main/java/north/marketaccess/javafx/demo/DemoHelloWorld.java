package north.marketaccess.javafx.demo;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.LabelBuilder;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class DemoHelloWorld extends Application {

  @Override
  public void start(Stage stage) throws Exception {
    // Create node
    Label textNode = LabelBuilder.create().text("Hello World !").alignment(Pos.CENTER).font(new Font(80)).build();

    // Create scene
    Scene scene = new Scene(textNode, 800, 400);

    // Init stage
    stage.setScene(scene);
    stage.setTitle("JavaFX 2");
    stage.show();
  }

  public static void main(String[] args) {
    Application.launch(args);
  }

}
