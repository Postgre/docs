package north.marketaccess.javafx.demo;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Book {

  private StringProperty title = new SimpleStringProperty();
  private StringProperty author = new SimpleStringProperty();
  private StringProperty editor = new SimpleStringProperty();

  private IntegerProperty pages = new SimpleIntegerProperty();

  private DoubleProperty price = new SimpleDoubleProperty();

  public Book(String title, String author, String editor, int pages, double price) {
    this.title = new SimpleStringProperty(title);
    this.author = new SimpleStringProperty(author);
    this.editor = new SimpleStringProperty(editor);
    this.pages = new SimpleIntegerProperty(pages);
    this.price = new SimpleDoubleProperty(price);
  }

  public String getTitle() {
    return title.getValue();
  }

  public void setTitle(String newTitle) {
    title.setValue(newTitle);
  }

  public String getAuthor() {
    return author.getValue();
  }

  public void setAuthor(String newAuthor) {
    author.setValue(newAuthor);
  }

  public String getEditor() {
    return editor.getValue();
  }

  public void setEditor(String newEditor) {
    editor.setValue(newEditor);
  }

  public int getPages() {
    return pages.getValue();
  }

  public void setPages(int newPages) {
    pages.setValue(newPages);
  }

  public double getPrice() {
    return price.getValue();
  }

  @Override
  public String toString() {
    return "Book[title=" + title + ", author=" + author + "]";
  }
}
