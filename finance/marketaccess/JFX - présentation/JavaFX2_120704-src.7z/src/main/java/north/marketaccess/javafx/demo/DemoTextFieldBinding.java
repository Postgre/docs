package north.marketaccess.javafx.demo;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.SceneBuilder;
import javafx.scene.control.TextField;
import javafx.scene.effect.Reflection;
import javafx.scene.effect.ReflectionBuilder;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderPaneBuilder;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextBuilder;
import javafx.stage.Stage;

public class DemoTextFieldBinding extends Application {

  @Override
  public void start(Stage stage) throws Exception {
    // Create Label
    Font font = Font.font(null, 80);
    Reflection reflection = ReflectionBuilder.create().fraction(0.8).build();
    Text label = TextBuilder.create().font(font).effect(reflection).fill(Color.DARKBLUE).build();

    // Create TextField
    TextField textField = new TextField("Second text");

    // Binding
    label.textProperty().bind(textField.textProperty());

    // Create root BorderPane
    BorderPane root = BorderPaneBuilder.create().center(label).bottom(textField).build();

    // Create scene
    Scene scene = SceneBuilder.create().root(root).width(800).height(600).build();

    stage.setScene(scene);
    stage.setTitle("TextField binding");
    stage.show();
  }

  public static void main(String[] args) {
    launch(args);
  }

}
